bulan = int(input("masukan bulan (1-12):"))

if (bulan == 2) :
    hari = 28
    print ("jumlah hari : 28")
elif (bulan == 1 or 3 or 5 or 7 or 8 or 10 or 12) :
    hari = 31
    print ("jumlah hari : 31")
elif (bulan == 4 or 6 or 9 or 11) :
    hari = 30
    print ("jumlah hari : 30")



