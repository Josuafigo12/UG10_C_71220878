print("--------------------menu--------------------")
print("kalkulator")
print("1. penjumlahan")
print("2. pengurangan")
print("3. perkalian")
print("4. pembagian")

pil = int(input("masukan pilhan operasi : "))


a= int(input("angka 1 : "))
b= int(input("angka 2 : "))

if pil ==1:
    hasil = a+b
elif pil == 2:
    hasil = a-b
elif pil == 3:
    hasil = a*b
elif pil == 4:
    hasil = a/b

print("sama dengan : %d" %hasil)
